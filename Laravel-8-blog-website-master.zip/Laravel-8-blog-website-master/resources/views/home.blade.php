@extends('frontlayout')
@section('title','Home Page')
@section('content')
<br>
<div class="row container-fluid">
<h4 style="margin-left: 475px;">Image Dashboard </h4>
<br>
		<!-- <div class=""> -->
			<div class="col-md-12">
			<br>
				<div class="row mb-3"> 
					@if(count($posts)>0)
						@foreach($posts as $post)
						<div class="col-md-3">
							<div class="card">
							  <a href="{{url('detail/'.Str::slug($post->title).'/'.$post->id)}}"><img src="{{asset('imgs/thumb/'.$post->thumb)}}" class="card-img-top" alt="{{$post->title}}" /></a>
							  <div class="card-body">
							    <h5 class="card-title"><a href="{{url('detail/'.Str::slug($post->title).'/'.$post->id)}}">{{$post->title}}</a></h5>
							  </div>
							</div>
						</div>
						@endforeach
					@else
					<p class="alert alert-danger">No Post Found</p>
					@endif
				</div>
				<!-- Pagination -->
				<br>
				<div style="margin-left: 925px;"> {{$posts->links()}} </div>
				
			</div>
			<!-- Right SIdebar -->
			
		<!-- </div> -->
		</div>
@endsection('content')
