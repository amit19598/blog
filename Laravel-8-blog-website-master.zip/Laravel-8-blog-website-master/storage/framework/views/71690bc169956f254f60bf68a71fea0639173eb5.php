<?php $__env->startSection('title','Manage Posts'); ?>
<?php $__env->startSection('content'); ?>
		<div class="row">
			<div class="col-md-8 mb-5">
				<h3 class="mb-4">Manage Posts</h3>
				<div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>#</th>
              <th>Category</th>
              <th>Title</th>
              <th>Image</th>
              <th>Full</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>#</th>
              <th>Category</th>
              <th>Title</th>
              <th>Image</th>
              <th>Full</th>
            </tr>
          </tfoot>
          <tbody>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($post->id); ?></td>
                <td><?php echo e($post->category->title); ?></td>
                <td><?php echo e($post->title); ?></td>
                <td><img src="<?php echo e(asset('imgs/thumb').'/'.$post->thumb); ?>" width="100" /></td>
                <td><img src="<?php echo e(asset('imgs/full').'/'.$post->full_img); ?>" width="100" /></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        </div>
			</div>
		</div>
<!-- Page level plugin CSS-->
<link href="<?php echo e(asset('backend')); ?>/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
<script src="<?php echo e(asset('backend')); ?>/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo e(asset('backend')); ?>/vendor/datatables/dataTables.bootstrap4.js"></script>
<script src="<?php echo e(asset('backend')); ?>/js/demo/datatables-demo.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\Laravel\Laravel-8-blog-website-master\Laravel-8-blog-website-master\resources\views/manage-posts.blade.php ENDPATH**/ ?>