<?php $__env->startSection('title','All Categories'); ?>
<?php $__env->startSection('content'); ?>
		<div class="row">
			<div class="col-md-8">
				<div class="row mb-5"> 
					<?php if(count($categories)>0): ?>
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-4">
							<div class="card">
							  <a href="<?php echo e(url('category/'.Str::slug($category->title).'/'.$category->id)); ?>"><img src="<?php echo e(asset('imgs/'.$category->image)); ?>" class="card-img-top" alt="<?php echo e($category->title); ?>" /></a>
							  <div class="card-body">
							    <h5 class="card-title"><a href="<?php echo e(url('category/'.Str::slug($category->title).'/'.$category->id)); ?>"><?php echo e($category->title); ?></a></h5>
							  </div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
					<p class="alert alert-danger">No Category Found</p>
					<?php endif; ?>
				</div>
				<!-- Pagination -->
				<?php echo e($categories->links()); ?>

			</div> 
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\Laravel\Laravel-8-blog-website-master\Laravel-8-blog-website-master\resources\views/categories.blade.php ENDPATH**/ ?>