<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib')); ?>/bs4/bootstrap.min.css" />
    <!-- Jquery -->
    <script type="text/javascript" src="<?php echo e(asset('lib')); ?>/jquery-3.5.1.min.js"></script>
    <!-- BS4 Js -->
    <script type="text/javascript" src="<?php echo e(asset('lib')); ?>/bs4/bootstrap.bundle.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    	<div class="container">
		  <a class="navbar-brand" href="<?php echo e(url('/')); ?>">VK Blogs</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="navbarNav">
		    <ul class="navbar-nav ml-auto">
		    
		      <?php if(auth()->guard()->guest()): ?>
			  <li class="nav-item active">
		        <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="<?php echo e(url('all-categories')); ?>">Categories</a>
		      </li>
			  <li class="nav-item">
		        <a class="nav-link" href="<?php echo e(url('login')); ?>">Login</a>
		      </li>
		      <?php else: ?>
			  <li class="nav-item active">
		        <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="<?php echo e(url('all-categories')); ?>">Categories</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="<?php echo e(url('save-post-form')); ?>">Add Post</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="<?php echo e(url('manage-posts')); ?>">Manage Posts</a>
		      </li>
			  <li class="nav-item">
		        <a class="nav-link" href="<?php echo e(url('register')); ?>">Register</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" href="<?php echo e(url('logout')); ?>">Logout</a>
		      </li>
		      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            	</form>
		      <?php endif; ?>
		    </ul>
		  </div>
		</div>
	</nav>
	<!-- Get latest posts -->
	<main class="container mt-4">
		<?php echo $__env->yieldContent('content'); ?>
	</main>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel-8-blog-website-master\resources\views/frontlayout.blade.php ENDPATH**/ ?>