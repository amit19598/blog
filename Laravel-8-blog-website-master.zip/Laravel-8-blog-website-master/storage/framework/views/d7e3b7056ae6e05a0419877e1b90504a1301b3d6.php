<?php echo e($viewdata->id); ?>

<?php echo e($viewdata->thumb); ?><?php /**PATH C:\xampp\htdocs\Laravel-8-blog-website-master\resources\views/viewpost.blade.php ENDPATH**/ ?>