<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="row container-fluid">
<h4 style="margin-left: 475px;">Image Dashboard </h4>
<br>
		<!-- <div class=""> -->
			<div class="col-md-12">
			<br>
				<div class="row mb-3"> 
					<?php if(count($posts)>0): ?>
						<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-3">
							<div class="card">
							  <a href="<?php echo e(url('detail/'.Str::slug($post->title).'/'.$post->id)); ?>"><img src="<?php echo e(asset('imgs/thumb/'.$post->thumb)); ?>" class="card-img-top" alt="<?php echo e($post->title); ?>" /></a>
							  <div class="card-body">
							    <h5 class="card-title"><a href="<?php echo e(url('detail/'.Str::slug($post->title).'/'.$post->id)); ?>"><?php echo e($post->title); ?></a></h5>
							  </div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
					<p class="alert alert-danger">No Post Found</p>
					<?php endif; ?>
				</div>
				<!-- Pagination -->
				<br>
				<div style="margin-left: 925px;"> <?php echo e($posts->links()); ?> </div>
				
			</div>
			<!-- Right SIdebar -->
			
		<!-- </div> -->
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-8-blog-website-master\resources\views/home.blade.php ENDPATH**/ ?>