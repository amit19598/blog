<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
		<div class="row">
			<div class="col-md-8">
				<div class="row mb-5"> 
					<?php if(count($posts)>0): ?>
						<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-4">
							<div class="card">
							  <a href="<?php echo e(url('detail/'.Str::slug($post->title).'/'.$post->id)); ?>"><img src="<?php echo e(asset('imgs/thumb/'.$post->thumb)); ?>" class="card-img-top" alt="<?php echo e($post->title); ?>" /></a>
							  <div class="card-body">
							    <h5 class="card-title"><a href="<?php echo e(url('detail/'.Str::slug($post->title).'/'.$post->id)); ?>"><?php echo e($post->title); ?></a></h5>
							  </div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
					<p class="alert alert-danger">No Post Found</p>
					<?php endif; ?>
				</div>
				<!-- Pagination -->
				<?php echo e($posts->links()); ?>

			</div>
			<!-- Right SIdebar -->
			
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\Laravel\Laravel-8-blog-website-master\Laravel-8-blog-website-master\resources\views/home.blade.php ENDPATH**/ ?>